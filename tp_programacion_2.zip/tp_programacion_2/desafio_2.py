class Triangulo:
    def __init__(self, l1, l2, l3):
        self.lado1 = l1
        self.lado2 = l2
        self.lado3 = l3

    def _es_valido(self):
        return (self.lado1 + self.lado2 > self.lado3 and
                self.lado1 + self.lado3 > self.lado2 and
                self.lado2 + self.lado3 > self.lado1)

    def consultar_lado_mayor(self):
        return max(self.lado1, self.lado2, self.lado3)

    def consultar_tipo_triangulo(self):
        if not self._es_valido():
            return "Inválido"

        if self.lado1 == self.lado2 and self.lado2 == self.lado3:
            return "Equilátero"
        elif self.lado1 == self.lado2 or self.lado1 == self.lado3 or self.lado2 == self.lado3:
            return "Isósceles"
        else:
            return "Escaleno"

if __name__ == "__main__":
    print("--- Carga de datos de un Triángulo ---")

    lados = []
    for i in range(1, 4):
        while True:
            try:
                lado_str = input(f"Ingrese la longitud del lado {i}: ")
                lado = float(lado_str)
                if lado <= 0:
                    print("¡Error! La longitud del lado debe ser un número positivo.")
                else:
                    lados.append(lado)
                    break
            except ValueError:
                print("¡Error! Por favor, ingrese un número válido.")

    mi_triangulo = Triangulo(lados[0], lados[1], lados[2])

    print("\n--- Consultando propiedades del Triángulo ---")

    lado_mayor = mi_triangulo.consultar_lado_mayor()
    print(f"El lado de mayor magnitud es: {lado_mayor}")

    tipo = mi_triangulo.consultar_tipo_triangulo()
    print(f"El tipo de triángulo es: {tipo}")

    print("\n--- Ejemplos predefinidos ---")

    t_equilatero = Triangulo(5, 5, 5)
    print(f"Tipo: {t_equilatero.consultar_tipo_triangulo()}, Lado Mayor: {t_equilatero.consultar_lado_mayor()}")

    t_isosceles = Triangulo(7, 7, 10)
    print(f"Tipo: {t_isosceles.consultar_tipo_triangulo()}, Lado Mayor: {t_isosceles.consultar_lado_mayor()}")

    t_escaleno = Triangulo(3, 4, 5)
    print(f"Tipo: {t_escaleno.consultar_tipo_triangulo()}, Lado Mayor: {t_escaleno.consultar_lado_mayor()}")

    t_invalido = Triangulo(1, 2, 10)
    print(f"Tipo: {t_invalido.consultar_tipo_triangulo()}, Lado Mayor: {t_invalido.consultar_lado_mayor()}")