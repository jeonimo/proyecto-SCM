class Producto:
    def __init__(self, codigo, nombre, precio, cantidad):
        self.codigo = codigo
        self.nombre = nombre
        self.precio = precio
        self.cantidad = cantidad

    def __str__(self):
        return f"Código: {self.codigo}, Nombre: {self.nombre}, Precio: ${self.precio:.2f}, Cantidad: {self.cantidad}"

class Stock:
    def __init__(self):
        self.productos = {}

    def agregar_producto(self):
        codigo = input("Ingrese código: ")
        if codigo in self.productos:
            print("El código ya existe.")
            return
        nombre = input("Ingrese nombre: ")
        precio = float(input("Ingrese precio: "))
        cantidad = int(input("Ingrese cantidad: "))
        producto = Producto(codigo, nombre, precio, cantidad)
        self.productos[codigo] = producto
        print("Producto agregado.")

    def eliminar_producto(self):
        codigo = input("Ingrese código del producto a eliminar: ")
        if codigo in self.productos:
            del self.productos[codigo]
            print("Producto eliminado.")
        else:
            print("Producto no encontrado.")

    def modificar_producto(self):
        codigo = input("Ingrese código del producto a modificar: ")
        if codigo in self.productos:
            producto = self.productos[codigo]
            campo = input("Ingrese campo a modificar (nombre, precio, cantidad): ")
            if campo == "nombre":
                producto.nombre = input("Ingrese nuevo nombre: ")
            elif campo == "precio":
                producto.precio = float(input("Ingrese nuevo precio: "))
            elif campo == "cantidad":
                producto.cantidad = int(input("Ingrese nueva cantidad: "))
            else:
                print("Campo inválido.")
                return
            print("Producto modificado.")
        else:
            print("Producto no encontrado.")

    def consultar_producto(self):
        codigo = input("Ingrese código del producto a consultar: ")
        if codigo in self.productos:
            print(self.productos[codigo])
        else:
            print("Producto no encontrado.")

    def listar_productos(self):
        if not self.productos:
            print("No hay productos en stock.")
            return
        for producto in self.productos.values():
            print(producto)

    def mostrar_menu(self):
        print("\n--- Menú de Opciones ---")
        print("1. Agregar producto")
        print("2. Eliminar producto")
        print("3. Modificar producto")
        print("4. Consultar producto")
        print("5. Listar productos")
        print("6. Salir")

    def ejecutar_opcion(self, opcion):
        if opcion == "1":
            self.agregar_producto()
        elif opcion == "2":
            self.eliminar_producto()
        elif opcion == "3":
            self.modificar_producto()
        elif opcion == "4":
            self.consultar_producto()
        elif opcion == "5":
            self.listar_productos()
        elif opcion == "6":
            print("Saliendo del programa.")
            return False
        else:
            print("Opción inválida. Intente de nuevo.")
        return True

stock = Stock()
ejecutando = True
while ejecutando:
    stock.mostrar_menu()
    opcion = input("Seleccione una opción: ")
    ejecutando = stock.ejecutar_opcion(opcion)