class Persona:
    def __init__(self, nombre="", edad=0, dni=""):
        self.__nombre = ""
        self.__edad = 0
        self.__dni = ""

        self.set_nombre(nombre)
        self.set_edad(edad)
        self.set_dni(dni)

    def get_nombre(self):
        return self.__nombre

    def get_edad(self):
        return self.__edad

    def get_dni(self):
        return self.__dni

    def set_nombre(self, nuevo_nombre):
        if isinstance(nuevo_nombre, str) and nuevo_nombre.strip() != "":
            self.__nombre = nuevo_nombre.strip()
        else:
            print("Error: El nombre no puede estar vacío y debe ser una cadena de texto.")

    def set_edad(self, nueva_edad):
        if isinstance(nueva_edad, int) and nueva_edad >= 0:
            self.__edad = nueva_edad
        else:
            print("Error: La edad debe ser un número entero no negativo.")

    def set_dni(self, nuevo_dni):
        if isinstance(nuevo_dni, str) and nuevo_dni.strip() != "":
            self.__dni = nuevo_dni.strip()
        else:
            print("Error: El DNI no puede estar vacío y debe ser una cadena de texto.")

    def mostrar(self):
        print("\n--- Datos de la Persona ---")
        print(f"Nombre: {self.get_nombre() if self.get_nombre() else 'No definido'}")
        print(f"Edad: {self.get_edad() if self.get_edad() > 0 else 'No definida'}")
        print(f"DNI: {self.get_dni() if self.get_dni() else 'No definido'}")
        print(f"¿Es mayor de edad?: {'Sí' if self.es_mayor_de_edad() else 'No'}")
        print("---------------------------")

    def es_mayor_de_edad(self, edad_minima=18):
        return self.__edad >= edad_minima and self.__edad > 0

# --- Función auxiliar para entrada de números ---
def solicitar_entero_valido(mensaje):
    while True:
        try:
            valor = int(input(mensaje))
            if valor < 0:
                print("El valor no puede ser negativo. Intente de nuevo.")
                continue
            return valor
        except ValueError:
            print("Entrada inválida. Por favor, ingrese un número entero.")

# --- Programa Principal Interactivo ---
if __name__ == "__main__":
    print("--- CREACIÓN INTERACTIVA DE PERSONAS ---")

    while True:
        print("\n--- Menú ---")
        print("1. Crear una nueva persona")
        print("2. Modificar una persona existente (por ahora, solo la última creada)")
        print("3. Salir")
        opcion_menu = input("Seleccione una opción: ")

        if opcion_menu == '1':
            print("\n--- Datos para la nueva Persona ---")
            nombre_input = input("Ingrese el nombre de la persona: ")
            edad_input = solicitar_entero_valido("Ingrese la edad de la persona: ")
            dni_input = input("Ingrese el DNI de la persona: ")

            persona_creada = Persona(nombre_input, edad_input, dni_input)
            persona_creada.mostrar()

        elif opcion_menu == '2':
            if 'persona_creada' not in locals():
                print("Primero debe crear una persona (Opción 1).")
                continue

            print(f"\n--- Modificando a {persona_creada.get_nombre()} ---")
            print("1. Modificar nombre")
            print("2. Modificar edad")
            print("3. Modificar DNI")
            print("4. Volver al menú principal")
            opcion_modificar = input("¿Qué desea modificar? ")

            if opcion_modificar == '1':
                nuevo_nombre = input("Ingrese el nuevo nombre: ")
                persona_creada.set_nombre(nuevo_nombre)
            elif opcion_modificar == '2':
                nueva_edad = solicitar_entero_valido("Ingrese la nueva edad: ")
                persona_creada.set_edad(nueva_edad)
            elif opcion_modificar == '3':
                nuevo_dni = input("Ingrese el nuevo DNI: ")
                persona_creada.set_dni(nuevo_dni)
            elif opcion_modificar == '4':
                continue
            else:
                print("Opción de modificación no válida.")
            persona_creada.mostrar() # Mostrar después de la modificación

        elif opcion_menu == '3':
            print("Saliendo del programa. ¡Hasta luego!")
            break
        else:
            print("Opción no válida. Por favor, intente de nuevo.")