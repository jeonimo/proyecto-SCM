class Agenda:
    def __init__(self):
        self.contactos = {}

    def crear_contacto(self, nombre, telefono, email):
        if nombre in self.contactos:
            print(f"Error: El contacto '{nombre}' ya existe.")
        else:
            self.contactos[nombre] = {'telefono': telefono, 'email': email}
            print(f"Contacto '{nombre}' creado exitosamente.")

    def borrar_contacto(self, nombre):
        if nombre in self.contactos:
            del self.contactos[nombre]
            print(f"Contacto '{nombre}' eliminado exitosamente.")
        else:
            print(f"Error: El contacto '{nombre}' no se encontró.")

    def editar_contacto(self, nombre, nuevo_telefono, nuevo_email):
        if nombre in self.contactos:
            self.contactos[nombre]['telefono'] = nuevo_telefono
            self.contactos[nombre]['email'] = nuevo_email
            print(f"Contacto '{nombre}' editado exitosamente.")
        else:
            print(f"Error: El contacto '{nombre}' no se encontró.")

    def listar_contactos(self):
        if not self.contactos:
            print("No hay contactos en la agenda.")
            return

        print("\n--- Lista de Contactos ---")
        for nombre, datos in self.contactos.items():
            print(f"Nombre: {nombre}")
            print(f"  Teléfono: {datos['telefono']}")
            print(f"  E-mail: {datos['email']}")
            print("------------------------")

    def buscar_contacto(self, nombre):
        if nombre in self.contactos:
            datos = self.contactos[nombre]
            print(f"\n--- Detalles de Contacto: {nombre} ---")
            print(f"  Teléfono: {datos['telefono']}")
            print(f"  E-mail: {datos['email']}")
            print("-----------------------------")
        else:
            print(f"El contacto '{nombre}' no se encontró en la agenda.")

def mostrar_menu():
    print("\n--- Menú de Opciones de la Agenda ---")
    print("1. Crear contacto")
    print("2. Borrar contacto")
    print("3. Editar contacto")
    print("4. Lista de contactos")
    print("5. Buscar contacto")
    print("6. Cerrar agenda")
    print("-----------------------------------")

if __name__ == "__main__":
    mi_agenda = Agenda()
    opcion = ""

    while opcion != "6":
        mostrar_menu()
        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            nombre = input("Ingrese el nombre del nuevo contacto: ")
            telefono = input("Ingrese el teléfono del nuevo contacto: ")
            email = input("Ingrese el e-mail del nuevo contacto: ")
            mi_agenda.crear_contacto(nombre, telefono, email)
        elif opcion == "2":
            nombre = input("Ingrese el nombre del contacto a borrar: ")
            mi_agenda.borrar_contacto(nombre)
        elif opcion == "3":
            nombre = input("Ingrese el nombre del contacto a editar: ")
            nuevo_telefono = input("Ingrese el NUEVO teléfono: ")
            nuevo_email = input("Ingrese el NUEVO e-mail: ")
            mi_agenda.editar_contacto(nombre, nuevo_telefono, nuevo_email)
        elif opcion == "4":
            mi_agenda.listar_contactos()
        elif opcion == "5":
            nombre = input("Ingrese el nombre del contacto a buscar: ")
            mi_agenda.buscar_contacto(nombre)
        elif opcion == "6":
            print("Cerrando la agenda. ¡Hasta luego!")
        else:
            print("Opción no válida. Por favor, intente de nuevo.")