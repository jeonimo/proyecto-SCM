class Cuenta:
    def __init__(self, titular, cantidad, tipo_cuenta):
        self.titular = titular
        self.cantidad = cantidad
        self.tipo_cuenta = tipo_cuenta

    def consultar_datos(self):
        print(f"--- Datos de la Cuenta ---")
        print(f"Titular: {self.titular}")
        print(f"Cantidad: ${self.cantidad:.2f}")
        print(f"Tipo de Cuenta: {self.tipo_cuenta}")
        print("--------------------------")


class CajaAhorro(Cuenta):
    def __init__(self, titular, cantidad):
        super().__init__(titular, cantidad, "Caja de Ahorro")

    def consultar_tipo_cuenta(self):
        return self.tipo_cuenta


class PlazoFijo(Cuenta):
    def __init__(self, titular, cantidad, plazo_dias, interes_anual):
        super().__init__(titular, cantidad, "Plazo Fijo")
        self.plazo = plazo_dias
        self.interes = interes_anual

    def obtener_importe_interes(self):
        interes_decimal = self.interes / 100
        interes_por_dia = interes_decimal / 365
        interes_generado = self.cantidad * interes_por_dia * self.plazo
        return interes_generado

    def consultar_datos(self):
        super().consultar_datos()
        print(f"Plazo: {self.plazo} días")
        print(f"Interés Anual: {self.interes}%")
        print(f"Interés Generado: ${self.obtener_importe_interes():.2f}")
        print("--------------------------")

    def consultar_titular(self):
        return self.titular

    def consultar_plazo(self):
        return self.plazo

    def consultar_interes(self):
        return self.interes

    def consultar_tipo_cuenta(self):
        return self.tipo_cuenta


def solicitar_numero_valido(mensaje, tipo=float):
    """Función auxiliar para solicitar y validar entradas numéricas."""
    while True:
        try:
            valor = tipo(input(mensaje))
            if valor < 0:
                print("El valor no puede ser negativo. Intente de nuevo.")
                continue
            return valor
        except ValueError:
            print("Entrada inválida. Por favor, ingrese un número.")

if __name__ == "__main__":
    cuentas_creadas = []

    print("--- CREACIÓN DE CUENTAS ---")
    while True:
        print("\n¿Qué tipo de cuenta desea crear?")
        print("1. Caja de Ahorro")
        print("2. Plazo Fijo")
        print("3. Terminar creación de cuentas")
        opcion_cuenta = input("Seleccione una opción (1-3): ")

        if opcion_cuenta == '1':
            print("\n-- Nueva Caja de Ahorro --")
            titular_ca = input("Ingrese el nombre del titular: ")
            cantidad_ca = solicitar_numero_valido("Ingrese la cantidad inicial: $")
            nueva_caja_ahorro = CajaAhorro(titular_ca, cantidad_ca)
            cuentas_creadas.append(nueva_caja_ahorro)
            print(f"Caja de Ahorro para '{titular_ca}' creada.")

        elif opcion_cuenta == '2':
            print("\n-- Nuevo Plazo Fijo --")
            titular_pf = input("Ingrese el nombre del titular: ")
            cantidad_pf = solicitar_numero_valido("Ingrese la cantidad a invertir: $")
            plazo_pf = int(solicitar_numero_valido("Ingrese el plazo en días: ", tipo=int))
            interes_pf = solicitar_numero_valido("Ingrese el interés anual (en %): ")
            nuevo_plazo_fijo = PlazoFijo(titular_pf, cantidad_pf, plazo_pf, interes_pf)
            cuentas_creadas.append(nuevo_plazo_fijo)
            print(f"Plazo Fijo para '{titular_pf}' creado.")

        elif opcion_cuenta == '3':
            print("Finalizando creación de cuentas.")
            break
        else:
            print("Opción no válida. Intente de nuevo.")

    if not cuentas_creadas:
        print("\nNo se crearon cuentas para mostrar.")
    else:
        print("\n--- RESUMEN DE TODAS LAS CUENTAS CREADAS ---")
        for i, cuenta in enumerate(cuentas_creadas):
            print(f"\n--- Cuenta #{i+1} ---")
            cuenta.consultar_datos()
            if isinstance(cuenta, CajaAhorro):
                print(f"Consultando tipo específico: {cuenta.consultar_tipo_cuenta()}")
            elif isinstance(cuenta, PlazoFijo):
                print(f"Consultando titular específico: {cuenta.consultar_titular()}")
                print(f"Consultando plazo específico: {cuenta.consultar_plazo()} días")
                print(f"Consultando interés específico: {cuenta.consultar_interes()}%")
                print(f"Consultando tipo específico: {cuenta.consultar_tipo_cuenta()}")