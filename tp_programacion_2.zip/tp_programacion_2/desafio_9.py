import math

class Circulo:
    def __init__(self, radio):
        self.radio = radio

    def calcular_area(self):
        return math.pi * (self.radio ** 2)

    def calcular_perimetro(self):
        return 2 * math.pi * self.radio

radio_circulo = float(input("ingresa el radio del circulo :"))

mi_circulo = Circulo(radio_circulo)
print(mi_circulo.calcular_area())
print(mi_circulo.calcular_perimetro())