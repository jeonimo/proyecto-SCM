class Cliente:
    def __init__(self, nombre_cliente):
        self.nombre = nombre_cliente
        self.cantidad = 0

    def depositar(self, monto):
        self.cantidad += monto
        print(f"Depósito de ${monto:.2f} realizado en la cuenta de {self.nombre}.")

    def extraer(self, monto):
        if self.cantidad >= monto:
            self.cantidad -= monto
            print(f"Extracción de ${monto:.2f} realizada de la cuenta de {self.nombre}.")
        else:
            print(f"Saldo insuficiente en la cuenta de {self.nombre}. Saldo actual: ${self.cantidad:.2f}")

    def get_total(self):
        return self.cantidad


class Banco:
    def __init__(self):
        self.clientes = [] # Usaremos una lista para almacenar los objetos Cliente

    def agregar_cliente(self, cliente):
        self.clientes.append(cliente)
        print(f"Cliente '{cliente.nombre}' agregado al banco.")

    def operar_cliente_interactivo(self, cliente):
        print(f"\n--- Operaciones para {cliente.nombre} ---")
        while True:
            print(f"Saldo actual: ${cliente.get_total():.2f}")
            print("1. Depositar")
            print("2. Extraer")
            print("3. Finalizar operaciones con este cliente")
            opcion = input("Elija una opción: ")

            if opcion == '1':
                while True:
                    try:
                        monto = float(input("Ingrese monto a depositar: $"))
                        if monto <= 0:
                            print("El monto debe ser positivo.")
                            continue
                        break
                    except ValueError:
                        print("Monto inválido. Por favor, ingrese un número.")
                cliente.depositar(monto)
            elif opcion == '2':
                while True:
                    try:
                        monto = float(input("Ingrese monto a extraer: $"))
                        if monto <= 0:
                            print("El monto debe ser positivo.")
                            continue
                        break
                    except ValueError:
                        print("Monto inválido. Por favor, ingrese un número.")
                cliente.extraer(monto)
            elif opcion == '3':
                print(f"Finalizando operaciones con {cliente.nombre}.")
                break
            else:
                print("Opción no válida. Intente de nuevo.")

    def deposito_total(self):
        total = sum(cliente.get_total() for cliente in self.clientes)
        print(f"\n--- Saldo Total del Banco ---")
        print(f"El total de dinero depositado en el banco es: ${total:.2f}")


if __name__ == "__main__":
    mi_banco = Banco()

    print("--- Configuración Inicial de Clientes ---")
    num_clientes = 0
    while True:
        try:
            num_clientes_str = input("¿Cuántos clientes desea agregar al banco? (Ej: 3): ")
            num_clientes = int(num_clientes_str)
            if num_clientes <= 0:
                print("Debe agregar al menos un cliente.")
                continue
            break
        except ValueError:
            print("Cantidad inválida. Por favor, ingrese un número entero.")

    for i in range(num_clientes):
        nombre_cliente = input(f"Ingrese el nombre del cliente {i+1}: ")
        nuevo_cliente = Cliente(nombre_cliente)
        mi_banco.agregar_cliente(nuevo_cliente)

    print("\n--- ¡Comencemos a Operar! ---")
    for cliente in mi_banco.clientes:
        mi_banco.operar_cliente_interactivo(cliente)

    mi_banco.deposito_total()
    print("Programa finalizado.")