class Calculadora:
    def __init__(self, num1, num2):
        self.numero1 = num1
        self.numero2 = num2

    def sumar(self):
        return self.numero1 + self.numero2

    def restar(self):
        return self.numero1 - self.numero2

    def multiplicar(self):
        return self.numero1 * self.numero2

    def dividir(self):
        if self.numero2 == 0:
            return "Error: No se puede dividir por cero."
        return self.numero1 / self.numero2

if __name__ == "__main__":
    print("--- Calculadora Básica ---")

    while True:
        try:
            val1 = int(input("Ingrese el primer valor entero: "))
            break
        except ValueError:
            print("¡Error! Por favor, ingrese un número entero válido.")

    while True:
        try:
            val2 = int(input("Ingrese el segundo valor entero: "))
            break
        except ValueError:
            print("¡Error! Por favor, ingrese un número entero válido.")

    mi_calculadora = Calculadora(val1, val2)

    print("\n--- Resultados de las Operaciones ---")
    print(f"Suma: {mi_calculadora.sumar()}")
    print(f"Resta: {mi_calculadora.restar()}")
    print(f"Multiplicación: {mi_calculadora.multiplicar()}")
    print(f"División: {mi_calculadora.dividir()}")