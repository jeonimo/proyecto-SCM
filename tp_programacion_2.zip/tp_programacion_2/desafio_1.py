class Estudiante:
    def __init__(self, nombre_inicial, nota_inicial):
        self.nombre = nombre_inicial
        self.nota_evaluacion = nota_inicial

    def obtener_nombre(self):
        return self.nombre

    def obtener_nota(self):
        return self.nota_evaluacion

    def ha_aprobado(self, nota_minima_aprobacion=6.0):
        return self.nota_evaluacion >= nota_minima_aprobacion

if __name__ == "__main__":
    print("--- Crear un nuevo Estudiante ---")

    nombre = input("Por favor, ingresa el nombre del estudiante: ")

    while True:
        try:
            nota_str = input(f"Ingresa la nota de evaluación de {nombre}: ")
            nota = float(nota_str)
            break  
        except ValueError:
            print("¡Error! Por favor, ingresa un número válido para la nota.")

    mi_estudiante = Estudiante(nombre, nota)

    print("\n--- Datos del Estudiante Ingresado ---")
    print(f"Nombre: {mi_estudiante.obtener_nombre()}")
    print(f"Nota: {mi_estudiante.obtener_nota()}")

    if mi_estudiante.ha_aprobado():
        print(f"¡Felicitaciones! {mi_estudiante.obtener_nombre()} ha aprobado la evaluación.")
    else:
        print(f"Lo siento, {mi_estudiante.obtener_nombre()} no ha aprobado la evaluación.")

    print("\n--- Prueba con otra nota mínima de aprobación (ej. 4.0) ---")
    if mi_estudiante.ha_aprobado(nota_minima_aprobacion=4.0):
        print(f"Según una nota mínima de 4.0, {mi_estudiante.obtener_nombre()} SÍ aprobaría.")
    else:
        print(f"Incluso con una nota mínima de 4.0, {mi_estudiante.obtener_nombre()} NO aprobaría.")