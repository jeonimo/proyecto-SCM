class Rectangulo:
    def __init__(self, base, altura):
        self.base = base
        self.altura = altura

    def calcular_area(self):
        return self.base * self.altura

base_rectangulo = float(input("ingresa la base del rectangulo: "))
altura_rectangulo = float(input("ingresa la altura del rectangulo: "))

mi_rectangulo = Rectangulo(base_rectangulo, altura_rectangulo)
print(mi_rectangulo.calcular_area())